# ruw
ruw (print random russian words for learning) 
